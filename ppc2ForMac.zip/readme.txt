ppc2 Readme

All of the following features can be viewed by control + h (help file)

This feature-rich calendar app is truly like no other.

It features:
    control + - for 2 smaller sizes
    control + = for 2 larger sizes
    control + c for 6 different highlight colors
    control + d for dark mode toggle
    control + e for European mode toggle
    control + h for help screen toggle
    control + p sends large, light-mode calendar to default printer
    control + q to quit
    control + s sends screenshot to Pictures folder

Also uses arrows and shift + arrows for navigation:
    Right arrow advances 1 month
    Left arrow goes back 1 month
    Up arrow advances 1 year
    Down arrow goes back 1 year
    Shift + Up arrow advances 10 years
    Shift + Down arrow goes back 10 years
    Shift + Right arrow displays current month and year

This app has my choice of holidays for the years 2026 to 2034 automatically loaded.
If you wish to edit these holiday files, they are easily editable json files.  Take care
when editing these files about quotation marks, commas and brackets.  Careful editing
will result in a pleasing result.

Also you can click on any date and enter a personal event just like in a spreadsheet.
The escape key can be used if you clicked on the wrong date to back out.  Also clicking
elsewhere can be used to back out.  Entering text and pressing the return key will store
the personal event in a json file in a secure location.  If you wish to delete a personal
event, then click on the date and press delete key until string is gone and then press
return key and event is deleted.

I put those last 3 items so that with just a few key strokes, you can find out what day
you were born on.  I was born on a Friday and my wife was born on a Sunday.  That is one
way that I could be sure that my calendar logic was running correctly when I was developing
this app.

Ed Garcia
Duson, LA
edgargarcia1949@gmail.com

